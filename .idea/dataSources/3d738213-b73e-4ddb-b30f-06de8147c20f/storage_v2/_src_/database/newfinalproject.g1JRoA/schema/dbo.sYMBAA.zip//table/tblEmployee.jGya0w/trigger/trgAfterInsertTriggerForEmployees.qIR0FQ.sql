CREATE TRIGGER trgAfterInsertTriggerForEmployees
ON tblEmployee
AFTER INSERT
AS
INSERT INTO tblEmployee_History VALUES ((SELECT TOP 1  inserted.tblEmployee_PKID FROM inserted),1, 'Insert')
go

