CREATE PROCEDURE [strdproPaid_UnpaidJobssssss] @pu char(3)
AS
SELECT (j.Name) AS Job_Name, (c.FirstName) AS Customer_Name
FROM tblJobs j
INNER JOIN tblJobStatus js ON j.tblJobStatus_FKID=js.tblJobStatus_PKID
INNER JOIN tblCustomer c ON j.tblCustomer_FKID=tblCustomer_PKID
WHERE js.[Paid_Y/N]=@pu;
go

