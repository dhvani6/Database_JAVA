CREATE VIEW [viewAllEmployeesFullNameeeee] AS
SELECT CONCAT(e.LastName,',',e.FirstName) as EmployeeName FROM tblEmployee e;
go

